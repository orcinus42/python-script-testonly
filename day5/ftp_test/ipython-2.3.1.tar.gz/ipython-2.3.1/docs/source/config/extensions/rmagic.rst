.. _extensions_rmagic:

===========
rmagic
===========

.. note::

   The rmagic extension has been moved to `rpy2 <http://rpy.sourceforge.net/rpy2.html>`_
   as :mod:`rpy2.interactive.ipython`.

.. automodule:: IPython.extensions.rmagic
