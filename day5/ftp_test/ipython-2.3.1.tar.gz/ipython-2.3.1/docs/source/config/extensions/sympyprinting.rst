.. _extensions_sympyprinting:

=============
sympyprinting
=============

.. automodule:: IPython.extensions.sympyprinting
